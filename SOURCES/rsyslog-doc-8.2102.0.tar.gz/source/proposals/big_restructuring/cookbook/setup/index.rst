Setup Cookbooks
===============


.. toctree::

    centralised_logging_logstash
