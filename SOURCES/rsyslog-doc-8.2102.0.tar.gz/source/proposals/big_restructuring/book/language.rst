Configuration format
====================

Currently there are two ways of creating your configuration
script: RainerScript and the legacy format.


RainerScript format
-------------------

General guidelines.


Legacy configuration format (deprecated)
----------------------------------------

General guidelines.


Why is there two different formats?
-----------------------------------

Explain!


  todo::

    Este item é do TO DO in language-rst.

