Input Configuration Reference
=============================

