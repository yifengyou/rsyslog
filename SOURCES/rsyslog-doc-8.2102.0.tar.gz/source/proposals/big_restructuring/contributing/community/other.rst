Other Resources
===============

In order to follow what is happening in the community you might find helpful
these additional resources:

* List of open pull requests `pull requests`_
* List of recent `commits`_
* List of open bugs and enhancements `bugs and enhancements`_

.. _pull requests:         https://github.com/rsyslog/rsyslog/pulls
.. _commits:               https://github.com/rsyslog/rsyslog/commits/master
.. _bugs and enhancements: https://github.com/rsyslog/rsyslog/issues
