Input Modules
-------------

Input modules are used to gather messages from various sources. They
interface to message generators. They are generally defined via the
:doc:`input <../input>` configuration object.

.. toctree::
   :glob:
   :maxdepth: 1

   im*

