********
strlen()
********

Purpose
=======

strlen(str)

Returns the length of the provided string.


Examples
========

In the following example returns the length of the message string.

.. code-block:: none

   strlen($msg)


