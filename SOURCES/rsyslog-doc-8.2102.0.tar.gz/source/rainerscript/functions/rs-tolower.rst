*********
tolower()
*********

Purpose
=======

tolower(str)

Converts the provided string into lowercase.


Example
=======

The following example shows the syslogtag being converted to lower case.

.. code-block:: none

   tolower($syslogtag)


