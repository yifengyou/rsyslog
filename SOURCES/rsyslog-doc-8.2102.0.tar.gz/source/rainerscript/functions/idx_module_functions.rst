****************
Module Functions
****************

You can make module functions accessible for the configuration by loading the
corresponding module. Once they are loaded, you can use them like any other
rainerscript function. If more than one function are part of the same module,
all functions will be available once the module is loaded.


.. toctree::
   :glob:
   :maxdepth: 1

   mo*

