ptcp Network Stream Driver
==========================

This network stream driver implement a plain tcp
transport without security properties.

Supported Driver Modes

-  0 - unencrypted transmission

Supported Authentication Modes

-  "anon" - no authentication
